﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace sqlite
{
    public partial class mainForm : Form
    {
        #region глобальные переменные
        // инициализируем глобальные переменные используемые во всей программе
        private sqliteclass mydb = null;  // подключаем класс sqliteclass в котором производим все манипуляции с БД
        private string sCurDir = string.Empty;
        private string sPath = string.Empty;
        private string sSql = string.Empty;
        public bool cheking = false;
        private string manualCmd = string.Empty;
        
        #endregion

        public mainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sPath = Path.Combine(Application.StartupPath, "mybd.sqlite");
            mainTextBox.Text = "БД успешно создана и располагается в:"+ Environment.NewLine + sPath + "\n";// Text = sPath; 
        }
        #region кнопки
        private void createButton_Click(object sender, EventArgs e)
        {
            mydb = new sqliteclass();
            // запрос создающий таблицу с определёнными полями
            if (cheking == true)
            {
                try
                {
                    sSql = cmdTextBox.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                sSql = @"CREATE TABLE if not exists [birthday]([id] INTEGER PRIMARY KEY AUTOINCREMENT,[FIO] TEXT NOT NULL,[bdate] datetime NOT NULL,[gretinyear] INTEGER DEFAULT 0);";
            }
            //Пытаемся создать таблицу
            if (sSql == null)
            {
                MessageBox.Show("Ничего не введено");
                return;
            }
            else
                mydb.execNonQuery(sPath, sSql, 0);

            /*
            //Проверка работы
            if (mydb.execNonQuery(sPath, sSql, 1) == 0)
            {
                MessageBox.Show("Ошибка проверки таблицы на запись, таблица или не создана или не прошла запись тестовой строки!");
                mydb = null;
                return;
            }
            sSql = "SELECT * FROM  birthday";
            DataRow[] datarows = mydb.dataRowExec(sPath, sSql);
            if (datarows == null)
            {
                MessageBox.Show("Ошибка проверки таблицы на чтение!");
                mydb = null;
                return;
            }
            foreach (DataRow dr in datarows)
            {
                mainTextBox.Text += dr["id"].ToString().Trim() + dr["FIO"].ToString().Trim() + dr["bdate"].ToString().Trim() + " ";
            }

            sSql = "DELETE FROM birthday";
            if (mydb.execNonQuery(sPath, sSql, 1) == 0)
            {
                MessageBox.Show("Ошибка проверки таблицы на удаление записи!");
                mydb = null;
                return;
            }
            */
            MessageBox.Show("Таблица создана!");
            mydb = null;
            return;

        }
        private void addButton_Click(object sender, EventArgs e)
        {
            mydb = new sqliteclass();
            if (cheking == true)
            {
                try
                {
                    sSql = cmdTextBox.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                sSql = @"INSERT INTO birthday (FIO,bdate,gretinyear) VALUES('Александр Сергеевич Пушкин','1799-06-06',0);";
                //Проверка работы
                if (mydb.execNonQuery(sPath, sSql, 1) == 0)
                {
                    MessageBox.Show("Ошибка записи!");
                }

                sSql = @"INSERT INTO birthday (FIO,bdate,gretinyear) VALUES('Толстой Лев Николаевич','1928-08-28',0);";
                if (mydb.execNonQuery(sPath, sSql, 1) == 0)
                {
                    MessageBox.Show("Ошибка записи!");
                }

                mydb = null;
                MessageBox.Show("Записи успешно добавлены!");
                return;
            }
        }

        private void readButton_Click(object sender, EventArgs e)
        {
            mydb = new sqliteclass();
            if (cheking == true)
            {
                try
                {
                    sSql = cmdTextBox.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                sSql = "SELECT * FROM  birthday";
                DataRow[] datarows = mydb.dataRowExec(sPath, sSql);
                if (datarows == null)
                {
                    MessageBox.Show("Ошибка чтения!");
                    mydb = null;
                    return;
                }
                foreach (DataRow dr in datarows)
                {
                    mainTextBox.Text += dr["id"].ToString().Trim() + "  " + dr["FIO"].ToString().Trim() + "  " + dr["bdate"].ToString().Trim() + Environment.NewLine;
                }
            }
        }

        private void ereaseButton_Click(object sender, EventArgs e)
        {
            mydb = new sqliteclass();
            if (cheking == true)
            {
                try
                {
                    sSql = cmdTextBox.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                sSql = "DELETE FROM  birthday";
                if (mydb.execNonQuery(sPath, sSql, 1) == 0)
                {
                    //mainTextBox.Text = "Ошибка удаления записи!";
                    MessageBox.Show("Ошибка удаления записи!");
                    mydb = null;
                    return;
                }
                mydb = null;
                mainTextBox.Text = "Записи удалены из БД!";
                return;
            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            if (cheking == true)
            {
                try
                {
                    sSql = cmdTextBox.Text;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                mydb = new sqliteclass();
                sSql = @"UPDATE birthday SET bdate='1828-08-28' WHERE FIO LIKE('%Толстой%');";
                //Проверка работы
                if (mydb.execNonQuery(sPath, sSql, 1) == 0)
                {
                    //mainTextBox.Text = "Ошибка обновления записи!";
                    MessageBox.Show("Ошибка редактирования записи!");
                    mydb = null;
                    return;
                }
                mydb = null;
                //mainTextBox.Text = "Запись исправлена!";
                MessageBox.Show("Запись успешно отредактирована!");
            }
        }
        #endregion

        private void boolChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (cheking == false)
            {
                cheking = true;
            }
            else
            {
                cheking = false;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            manualCmd = cmdTextBox.Text;
            mydb = new sqliteclass();

            mydb.execNonQuery(sPath, manualCmd, 1);
            
            MessageBox.Show("Запись успешно отредактирована!");
            sSql = "SELECT * FROM  birthday";
            DataRow[] datarows = mydb.dataRowExec(sPath, sSql);

            foreach (DataRow dr in datarows)
            {
                mainTextBox.Text += dr["id"].ToString().Trim() + "  " + dr["FIO"].ToString().Trim() + "  " + dr["bdate"].ToString().Trim() + Environment.NewLine;
            }
           
        }

    }
}
