﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SQLite;

namespace sqlite
{
    /// <summary>
    /// Удобный класс для работы с SQLite
    /// </summary>
    class Sqliteclass
    {
        private string sqlError;
        /// <summary>
        /// Ошибка запроса
        /// </summary>
        public string SqlError
        {
            get { return sqlError; }
        }

        #region Основные переменные
        string _filename = ""; // путь до бд
        // экземпляры классов
        SQLiteConnection connect;
        SQLiteCommand command = new SQLiteCommand();
        // позволяет формировать запросы более сложного вида (с указанием разнообразных параметров)
        // см. содержимое System.Data.SQLite.SQLiteConnectionStringBuilder
        SQLiteConnectionStringBuilder csb = new SQLiteConnectionStringBuilder();
        
        #endregion
        /// <summary>
        /// Имя файла базы данных
        /// </summary>
        public string Filename
        {
            get { return _filename; }
            set
            {
                _filename = value;
                // для csb
                csb.DataSource = _filename;
                csb.UseUTF16Encoding = true;
                csb.Add("New", true);
                
                connect = new SQLiteConnection(csb.ToString());
            }
        }
        #region Конструктор (с перегрузками)
        //Конструктор
        /// <summary>
        /// Создание экзмепляра класса манипуляци с бд
        /// </summary>
        /// <param name="fileName">Путь до файла базы данных</param>
        public Sqliteclass(string fileName)
        {
            this.Filename = fileName;
        }
        
        /// <summary>
        /// Создание экзмепляра класса манипуляци с бд
        /// </summary>
        /// <param name="fileName">Путь до файла бд</param>
        /// <param name="csb">Построитель строк подключения © MSDN</param>
        public Sqliteclass(string fileName, SQLiteConnectionStringBuilder csb)
        {
            this.csb = csb;
            this.Filename = fileName;
        }
        #endregion
        
        /// <summary>
        /// Версия SQLite
        /// </summary>
        public string Version
        {
            get { return connect.ServerVersion; }
        }
        
        /// <summary>
        /// Информация о таблице.
        /// </summary>
        /// <param name="tableName">Имя таблицы</param>
        /// <returns>Перечисленные колонки в виде List&lt;string&gt;</returns>
        public List<string> TableInfo(string tableName)
        {
            List<string> columns = new List<string>();
            DataTable dt = Execute(string.Format("PRAGMA table_info([{0}])", tableName));
            foreach (DataRow row in dt.Rows)
            {
                columns.Add(row[0].ToString());
            }
            return columns;
        }
        
        #region Открытие и закрытие подключения
        /// <summary>
        /// Открытие подключения
        /// </summary>
        /// <returns>True - успех</returns>
        public bool Open()
        {
            try
            {
                connect.Open();
                return true;
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return false;
            }
        }
        
        /// <summary>
        /// Закрытие подключения
        /// </summary>
        /// <returns>True - успех</returns>
        public bool Close()
        {
            try
            {
                if (connect.State == ConnectionState.Open)
                    connect.Close();
                return true;
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return false;
            }
        }
        #endregion
        
        #region Выполнение любого запроса без получения ответа (простые запросы)
        /// <summary>
        /// Выполнение без получения ответа
        /// </summary>
        /// <param name="query">Строка запроса</param>
        /// <returns>Код ошибки. Если 0, ошибки нет</returns>
        public int ExecuteNonQuery(string query)
        {
            return ExecuteNonQuery(new string[] { query });
        }
        
        /// <summary>
        /// Выполняет множественный запрос к базе данных.
        /// </summary>
        /// <param name="queries">Массив запросов</param>
        /// <returns>Код ошибки. Если 0 - ошибки нет</returns>
        public int ExecuteNonQuery(object[] queries)
        {
            ConnectionState previousConnectionState = ConnectionState.Closed;
            try
            {
                // проверяем предыдущее состояние
                previousConnectionState = connect.State;
                if (connect.State == ConnectionState.Closed)
                {
                    // открываем соединение
                    connect.Open();
                }
                // выполняем запросы
                SQLiteCommand command = new SQLiteCommand(connect);
                foreach (string query in queries)
                {
                    command.CommandText = query;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return 1;
            }
            finally
            {
                // закрываем соединение, если оно было закрыто перед открытием
                if (previousConnectionState == ConnectionState.Closed)
                {
                    connect.Close();
                }
            }
            // если нет ошибки
            return 0;
        }
        #endregion
        
        /// <summary>
        /// Массив колонок в строку
        /// </summary>
        /// <param name="columns">Массив колонок</param>
        /// <returns>Колонки через запятую</returns>
        private string columnsToLine(string[] columns)
        {
            string textofcolumns = string.Empty;
            if (columns == null || columns.Length == 0)
                textofcolumns = "*";
            else
            {
                textofcolumns = string.Join(",", columns);
            }
            return textofcolumns.ToString();
        }
        
        #region Получение данных
        /// <summary>
        /// Выполнение (exec и последующее возвращение данных)
        /// </summary>
        /// <param name="query">Строка запроса</param>
        /// <returns>Таблица с данными</returns>
        private DataTable Execute(string query)
        {
            DataTable dt = new DataTable();
            ConnectionState previousConnectionState = ConnectionState.Closed;
            try
            {
                previousConnectionState = connect.State;
                if (connect.State == ConnectionState.Closed)
                {
                    connect.Open();
                }
                command = new SQLiteCommand(query, connect);
                SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);
                adapter.Fill(dt);
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return null;
            }
            finally
            {
                if (previousConnectionState == ConnectionState.Closed)
                {
                    connect.Close();
                }
            }
            return dt;
        }
        
        /// <summary>
        /// Получает все данные из таблицы
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchAll(string tablename)
        {
            return FetchAll(tablename, "", "");
        }
        
        /// <summary>
        /// Получает данные все из таблицы
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchAll(string tablename, string where)
        {
            return FetchAll(tablename, where, "");
        }
        
        /// <summary>
        /// Получает данные из таблицы (с параметрами)
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <param name="etc">Остальные параметры: сортировка, группировка и т.д.</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchAll(string tablename, string where, string etc)
        {
            DataTable dt = new DataTable();
            if (!string.IsNullOrEmpty(where) && !where.ToLower().Trim().StartsWith("where"))
            {
                where = "WHERE " + where;
            }
            string sql = string.Format("SELECT * FROM {0} {1} {2}", tablename, where, etc);
            return Execute(sql);
        }
        
        /// <summary>
        /// Получение данных по выбранным полям (колонкам)
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Массив колонок, которые необходимо получить</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string[] columns)
        {
            return FetchByColumn(tablename, columns, "", "");
        }
        
        /// <summary>
        /// Получение данных по выбранным колонкам
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Строка колонок через запятую, которые необходимо получить</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string columns)
        {
            return FetchByColumn(tablename, columns, "", "");
        }
        
        /// <summary>
        /// Получение данных по выбранным колонкам
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Массив колонок, которые необходимо получить</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string[] columns, string where)
        {
            return FetchByColumn(tablename, columns, where, "");
        }

        /// <summary>
        /// Получение данных по выбранным колонкам
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Строка колонок через запятую, которые необходимо получить</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string columns, string where)
        {
            return FetchByColumn(tablename, columns, where, "");
        }

        /// <summary>
        /// Получение данных по выбранным колонкам
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Массив колонок, которые необходимо получить</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <param name="etc">Остальные параметры: сортировка, группировка и т.д.</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string[] columns, string where, string etc)
        {
            return FetchByColumn(tablename, columnsToLine(columns), where, etc);
        }

        /// <summary>
        /// Получение данных по выбранным колонкам
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Строка колонок через запятую, которые необходимо получить</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <param name="etc">Остальные параметры: сортировка, группировка и т.д.</param>
        /// <returns>Таблица с данными</returns>
        public DataTable FetchByColumn(string tablename, string columns, string where, string etc)
        {
            if (!string.IsNullOrEmpty(where) && !where.ToLower().Trim().StartsWith("where"))
            {
                where = "WHERE " + where;
            }
            
            // если не задано имя таблицы
            if (string.IsNullOrEmpty(tablename))
            {
                // выходим из метода
                return null;
            }
            
            string sql = string.Format("SELECT {0} FROM {1} {2} {3}", columns, tablename, where, etc);
            return Execute(sql);
        }
        #endregion
        
        #region Допилить вставку данных
        // ыть
        // аналогично упдате должно быть - коллекция данных, которые надо вставлять
        #endregion
        
        #region Допилить упдате
        // ыть
        // надо передавать параметры (что упдатить) через список (колекцию)
        #endregion
        
        #region Удаление данных
        /// <summary>
        /// Удаляет все данные из таблицы
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <returns>Код ошибки</returns>
        public int Del(string tablename)
        {
            // если не задано имя таблицы
            if (string.IsNullOrEmpty(tablename))
            {
                // выходим из метода
                return 1;
            }

            string sql = string.Format("DELETE FROM {0}", tablename);
            ConnectionState previousConnectionState = ConnectionState.Closed;
            try
            {
                previousConnectionState = connect.State;
                if (connect.State == ConnectionState.Closed)
                {
                    connect.Open();
                }
                command = new SQLiteCommand(sql, connect);
                command.ExecuteNonQuery();
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return 1;
            }
            finally
            {
                if (previousConnectionState == ConnectionState.Closed)
                {
                    connect.Close();
                }
            }
            return 0;
        }

        /// <summary>
        /// Удаляет все данные по условию
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="where">Строка условий, начинающихся с WHERE</param>
        /// <returns>Код ошибки</returns>
        public int Del(string tablename, string where)
        {
            // если не задано имя таблицы
            if (string.IsNullOrEmpty(tablename))
            {
                // выходим из метода
                return 1;
            }
            
            if (!string.IsNullOrEmpty(where) && !where.ToLower().Trim().StartsWith("where"))
            {
                where = "WHERE " + where;
            }
            string sql = string.Format("DELETE FROM {0} {1}", tablename, where);
            ConnectionState previousConnectionState = ConnectionState.Closed;
            try
            {
                previousConnectionState = connect.State;
                if (connect.State == ConnectionState.Closed)
                {
                    connect.Open();
                }
                
                command = new SQLiteCommand(sql, connect);
                command.ExecuteNonQuery();
            }
            catch (Exception error)
            {
                sqlError = string.Format("Ошибка:{0}!\n", error.Message);
                return 1;
            }
            finally
            {
                if (previousConnectionState == ConnectionState.Closed)
                {
                    connect.Close();
                }
            }
            return 0;
        }
        #endregion
    }
}