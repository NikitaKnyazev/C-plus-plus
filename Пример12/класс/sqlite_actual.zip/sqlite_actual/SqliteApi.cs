﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;

namespace sqlite
{
    /// <summary>
    /// Реализация API SQLite
    /// </summary>
    public class SqliteApi
    {
        #region Константы команд
        const string DISTINCT = "distinct";
        const string COLUMNS = "columns";
        const string FROM = "from";
        const string UNION = "union";
        const string WHERE = "where";
        const string GROUP = "group";
        const string HAVING = "having";
        const string ORDER = "order";
        const string LIMIT_COUNT = "limitcount";
        const string LIMIT_OFFSET = "limitoffset";
        const string FOR_UPDATE = "forupdate";
        //связывание
        const string INNER_JOIN = "inner join";
        const string LEFT_JOIN = "left join";
        const string RIGHT_JOIN = "right join";
        const string FULL_JOIN = "full join";
        const string CROSS_JOIN = "cross join";
        const string NATURAL_JOIN = "natural join";

        const string SQL_WILDCARD = "*";
        const string SQL_SELECT = "SELECT";
        const string SQL_UNION = "UNION";
        const string SQL_UNION_ALL = "UNION ALL";
        const string SQL_FROM = "FROM";
        const string SQL_WHERE = "WHERE";
        const string SQL_DISTINCT = "DISTINCT";
        const string SQL_GROUP_BY = "GROUP BY";
        const string SQL_ORDER_BY = "ORDER BY";
        const string SQL_HAVING = "HAVING";
        const string SQL_FOR_UPDATE = "FOR UPDATE";
        const string SQL_AND = "AND";
        const string SQL_AS = "AS";
        const string SQL_OR = "OR";
        const string SQL_ON = "ON";
        const string SQL_ASC = "ASC";
        const string SQL_DESC = "DESC";
        const string SQL_LIMIT = "LIMIT";
        #endregion
        #region Внутренние переменные
        string _from = string.Empty;
        string _columns = "*";
        string _where = string.Empty;
        string _group = string.Empty;
        string _having = string.Empty;
        string _order = string.Empty;
        int _limitCount = 0, _limitOffset = 0;
        string _selectError = string.Empty;
        // для связывания
        List<JoinObj> _collectionJoin = new List<JoinObj>();
        #endregion

        /// <summary>
        /// Выводит строку запроса
        /// </summary>
        public string SelectCommand
        {
            get { return _constructor(); }
        }

        /// <summary>
        /// Строка запроса
        /// </summary>
        /// <returns>Текст запроса к бд</returns>
        public override string ToString()
        {
            return _constructor();
        }

        /// <summary>
        /// Ошибка Select'а
        /// </summary>
        public string SelectError
        {
            get { return _selectError; }
        }

        #region Публичные методы
        #region From
        /// <summary>
        /// Задать имя таблицы для запроса
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi From(string tablename)
        {
            this._from = tablename;
            return this;
        }

        /// <summary>
        /// Задать имя таблицы и возвращаемые поля для запроса
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Поля, которые нужно получить</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi From(string tablename, string[] columns)
        {
            this._from = tablename;

            if (columns == null || columns.Length == 0)
            {
                this._columns = SQL_WILDCARD;
            }
            else
                this._columns = columnsToLine(columns);
            return this;
        }

        /// <summary>
        /// Задать имя таблицы и возвращаемые поля для запроса
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="columns">Поля, которые нужно получить</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi From(string tablename, string columns)
        {
            this._from = tablename;

            if (columns == null || columns.Length == 0)
            {
                this._columns = SQL_WILDCARD;
            }
            else
                this._columns = columns;
            return this;
        }
        #endregion

        #region Columns
        /// <summary>
        /// Задать список полей, которые будут возвращены 
        /// </summary>
        /// <param name="columns">Поля, которые нужно получить</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Columns(string[] columns)
        {
            if (columns == null || columns.Length == 0)
            {
                this._columns = SQL_WILDCARD;
            }
            else
                this._columns = columnsToLine(columns);
            return this;
        }

        /// <summary>
        /// Задать список полей, которые будут возвращены
        /// </summary>
        /// <param name="columns">Поля, которые нужно получить</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Columns(string columns)
        {
            if (columns == null || columns.Length == 0)
            {
                this._columns = SQL_WILDCARD;
            }
            else
                this._columns = columns;
            return this;
        }
        #endregion

        #region Прочие команды
        /// <summary>
        /// Условия
        /// </summary>
        /// <param name="where">Перечисление условий</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Where(string where)
        {
            this._where = " " + where;
            return this;
        }

        /// <summary>
        /// Группировка
        /// </summary>
        /// <param name="group">Поле/поля через запятую для группировки</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Group(string group)
        {
            this._group = group;
            return this;
        }

        /// <summary>
        /// Сортировка
        /// </summary>
        /// <param name="order">Поле для группировки</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Order(string order)
        {
            this._order = order;
            return this;
        }

        /// <summary>
        /// Связывание таблиц
        /// </summary>
        /// <param name="name">Имя таблицы с которой связываемся</param>
        /// <param name="conditional">Условия связывания</param>
        /// <param name="type">Тип связывания</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Join(string name, string conditional, SQLJoinTypes type)
        {
            _collectionJoin.Add(new JoinObj(name, conditional, type));
            return this;
        }


        /// <summary>
        /// Лимит на выборку
        /// </summary>
        /// <param name="count">Количество записей</param>
        /// <returns>Объект для создания строки запроса</returns>
        public SqliteApi Limit(int count)
        {
            this._limitCount = count;
            this._limitOffset = 0;
            return this;
        }
        #endregion

        /// <summary>
        /// Генератор запроса к sql
        /// </summary>
        /// <returns>Строка запроса к бд</returns>
        private string _constructor()
        {
            string sqlcommand = string.Empty;
            if (_from.Length == 0)
            {
                _selectError = "Не определено имя таблицы";
                return "";
            }

            sqlcommand = string.Format("SELECT {0} {1} {2} ", _columns, SQL_FROM, _from);

            // Join
            foreach (JoinObj join in _collectionJoin)
            {
                sqlcommand += string.Format("{0} {1} ON {2} ", join.SQLJoinType, join.Name, join.Conditional);
            }

            // условие
            sqlcommand += _where.Length > 0 ? SQL_WHERE + " " + _where : "";

            // группировка
            if (_group.Length > 0)
            {
                sqlcommand += " " + SQL_GROUP_BY + " " + _group;
            }

            // вычисление табличного выражения
            if (_having.Length > 0)
            {
                sqlcommand += " " + SQL_HAVING + " " + _having;
            }

            // сортировка
            if (_order.Length > 0)
            {
                sqlcommand += " " + SQL_ORDER_BY + " " + _order;
            }

            // лимит
            if (_limitCount > 0)
            {
                sqlcommand += " " + SQL_LIMIT + " " + _limitCount;
            }
            if (_limitOffset > 0)
            {
                sqlcommand += "," + _limitOffset;
            }

            return sqlcommand;
        }
        #endregion

        /// <summary>
        /// Перевод массива колонок в строку, через запятую
        /// </summary>
        /// <param name="columns">Массив колонок</param>
        /// <returns>Колонки через запятую</returns>
        private string columnsToLine(string[] columns)
        {
            string textofcolumns = string.Empty;
            if (columns == null || columns.Length == 0)
                textofcolumns = "*";
            else
            {
                textofcolumns = string.Join(",", columns);
            }
            return textofcolumns.ToString();
        }

        /// <summary>
        /// Типы связывания таблиц между собой (SQL-92 спецификация)
        /// </summary>
        public enum SQLJoinTypes
        {
            INNER_JOIN = 1,
            LEFT_JOIN,
            RIGHT_JOIN,
            FULL_JOIN,
            CROSS_JOIN,
            NATURAL_JOIN
        }
        /// <summary>
        /// Подкласс для связывания таблиц между собой
        /// </summary>
        private class JoinObj
        {
            string _name, _conditional;
            SQLJoinTypes _type;

            /// <summary>
            /// Условное выражение
            /// </summary>
            public string Conditional
            {
                get { return _conditional; }
            }

            /// <summary>
            /// Имя таблицы
            /// </summary>
            public string Name
            {
                get { return _name; }
            }

            /// <summary>
            /// Тип связывания
            /// </summary>
            public string SQLJoinType
            {
                get
                {
                    switch (_type)
                    {
                        case SQLJoinTypes.INNER_JOIN:
                            return INNER_JOIN;
                        case SQLJoinTypes.LEFT_JOIN:
                            return LEFT_JOIN;
                        case SQLJoinTypes.RIGHT_JOIN:
                            return RIGHT_JOIN;
                        case SQLJoinTypes.FULL_JOIN:
                            return FULL_JOIN;
                        case SQLJoinTypes.CROSS_JOIN:
                            return CROSS_JOIN;
                        case SQLJoinTypes.NATURAL_JOIN:
                            return NATURAL_JOIN;

                        default: return "";
                    }
                }
            }
            
            /// <summary>
            /// Cвязывание
            /// </summary>
            /// <param name="name">Имя таблицы</param>
            /// <param name="conditional">Условие</param>
            /// <param name="type">Тип связывания</param>
            public JoinObj(string name, string conditional, SQLJoinTypes type)
            {
                this._name = name;
                this._conditional = conditional;
                this._type = type;
            }
        }
    }
}
