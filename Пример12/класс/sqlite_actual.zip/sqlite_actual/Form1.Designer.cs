﻿namespace sqlite
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.editButton = new System.Windows.Forms.Button();
            this.ereaseButton = new System.Windows.Forms.Button();
            this.readButton = new System.Windows.Forms.Button();
            this.inputButton = new System.Windows.Forms.Button();
            this.createButton = new System.Windows.Forms.Button();
            this.mainTextBox = new System.Windows.Forms.TextBox();
            this.boolLabel = new System.Windows.Forms.Label();
            this.cmdTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.okButton = new System.Windows.Forms.Button();
            this.tableButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(336, 236);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(107, 35);
            this.editButton.TabIndex = 11;
            this.editButton.Text = "Редактирование таблицы";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // ereaseButton
            // 
            this.ereaseButton.Location = new System.Drawing.Point(255, 236);
            this.ereaseButton.Name = "ereaseButton";
            this.ereaseButton.Size = new System.Drawing.Size(75, 35);
            this.ereaseButton.TabIndex = 10;
            this.ereaseButton.Text = "Очистка";
            this.ereaseButton.UseVisualStyleBackColor = true;
            this.ereaseButton.Click += new System.EventHandler(this.ereaseButton_Click);
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(174, 236);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(75, 35);
            this.readButton.TabIndex = 9;
            this.readButton.Text = "Считать таблицу";
            this.readButton.UseVisualStyleBackColor = true;
            this.readButton.Click += new System.EventHandler(this.readButton_Click);
            // 
            // inputButton
            // 
            this.inputButton.Location = new System.Drawing.Point(93, 236);
            this.inputButton.Name = "inputButton";
            this.inputButton.Size = new System.Drawing.Size(75, 35);
            this.inputButton.TabIndex = 7;
            this.inputButton.Text = "Добавить запись";
            this.inputButton.UseVisualStyleBackColor = true;
            this.inputButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(12, 236);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 35);
            this.createButton.TabIndex = 6;
            this.createButton.Text = "Создать таблицу";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // mainTextBox
            // 
            this.mainTextBox.Location = new System.Drawing.Point(12, 12);
            this.mainTextBox.Multiline = true;
            this.mainTextBox.Name = "mainTextBox";
            this.mainTextBox.Size = new System.Drawing.Size(431, 218);
            this.mainTextBox.TabIndex = 12;
            // 
            // boolLabel
            // 
            this.boolLabel.AutoSize = true;
            this.boolLabel.Location = new System.Drawing.Point(9, 304);
            this.boolLabel.Name = "boolLabel";
            this.boolLabel.Size = new System.Drawing.Size(113, 13);
            this.boolLabel.TabIndex = 14;
            this.boolLabel.Text = "Ручной ввод команд:";
            // 
            // cmdTextBox
            // 
            this.cmdTextBox.Location = new System.Drawing.Point(149, 301);
            this.cmdTextBox.Name = "cmdTextBox";
            this.cmdTextBox.Size = new System.Drawing.Size(614, 20);
            this.cmdTextBox.TabIndex = 15;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(449, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(314, 218);
            this.dataGridView1.TabIndex = 19;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(688, 327);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 18;
            this.okButton.Text = "Ок";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // tableButton
            // 
            this.tableButton.Location = new System.Drawing.Point(544, 236);
            this.tableButton.Name = "tableButton";
            this.tableButton.Size = new System.Drawing.Size(107, 35);
            this.tableButton.TabIndex = 20;
            this.tableButton.Text = "Отобразить таблицу";
            this.tableButton.UseVisualStyleBackColor = true;
            this.tableButton.Click += new System.EventHandler(this.tableButton_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 363);
            this.Controls.Add(this.tableButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.cmdTextBox);
            this.Controls.Add(this.boolLabel);
            this.Controls.Add(this.mainTextBox);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.ereaseButton);
            this.Controls.Add(this.readButton);
            this.Controls.Add(this.inputButton);
            this.Controls.Add(this.createButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "mainForm";
            this.Text = "Пример использования SQLite";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button ereaseButton;
        private System.Windows.Forms.Button readButton;
        private System.Windows.Forms.Button inputButton;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.TextBox mainTextBox;
        private System.Windows.Forms.Label boolLabel;
        private System.Windows.Forms.TextBox cmdTextBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button tableButton;
    }
}

