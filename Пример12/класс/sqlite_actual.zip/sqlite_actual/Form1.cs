﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace sqlite
{
    public partial class mainForm : Form
    {
        

        #region глобальные переменные
        // подключаем класс Sqliteclass в котором производим все манипуляции с БД
        Sqliteclass mydb;
        SqliteApi penya;

        // 2 переменные для удобства (sPath - путь к файлу бд, sSql - sql запрос), без которых можно обойтись
        private string sPath = string.Empty;
        private string sSql = string.Empty;
        #endregion

        public mainForm()
        {
            InitializeComponent();
        } 

        private void Form1_Load(object sender, EventArgs e)
        {
            // тут можно задать произвольное имя файла бд, по идее можно вывести на форму
            sPath = Path.Combine(Application.StartupPath, "sql.sqlite");
            if (!File.Exists(sPath))
            {
                File.Create(sPath, 4096);
            }
            mydb = new Sqliteclass(sPath);
            mainTextBox.Text = "БД успешно создана и располагается в:"+ Environment.NewLine + sPath+ Environment.NewLine;
        }

        #region кнопки
        private void createButton_Click(object sender, EventArgs e)
        {
            // запрос создающий таблицу с определёнными полями
            sSql = @"CREATE TABLE if not exists [birthday]([id] INTEGER PRIMARY KEY AUTOINCREMENT,[FIO] TEXT NOT NULL,[bdate] TEXT NOT NULL,[comment] TEXT NOT NULL);";
            if (mydb.ExecuteNonQuery(sSql) == 1)
            {
                MessageBox.Show(mydb.SqlError.ToString());
            }
            else
                MessageBox.Show("Таблица создана!");
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // массив строк
            string[] multsSql = { @"INSERT INTO birthday (FIO,bdate,comment) VALUES('Александр Сергеевич Пушкин','1799-06-06','Сашка');",
                                  @"INSERT INTO birthday (FIO,bdate,comment) VALUES('Толстой Лев Николаевич','1928-08-28','Алёшенька');"
                                };
            // множественный запрос
            if (mydb.ExecuteNonQuery(multsSql) == 1)
            {
                MessageBox.Show(mydb.SqlError.ToString());
            }
            else
                MessageBox.Show("Записи успешно добавлены!");
        }

        private void readButton_Click(object sender, EventArgs e)
        {
            // создаём датаров и делаем в него селекхт по имени бд (выборка по строкам)
            DataRow[] dr = null;
            dr = mydb.FetchAll("birthday").Select();

            // вынимаем данные
            foreach (DataRow pepe in dr)
            {
                mainTextBox.Text += pepe["id"].ToString().Trim() + "  " + pepe["FIO"].ToString().Trim() + "  " + pepe["bdate"].ToString().Trim() + Environment.NewLine;
            }
        }

        private void ereaseButton_Click(object sender, EventArgs e)
        {
            if (mydb.Del("birthday") == 1)
            {
                MessageBox.Show(mydb.SqlError.ToString());
            }
            else
                mainTextBox.Text = "Записи удалены из БД!\n";
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            sSql = @"UPDATE birthday SET bdate='1228-12-05' WHERE FIO LIKE('%Толстой%');";
            if (mydb.ExecuteNonQuery(sSql) == 1)
            {
                MessageBox.Show(mydb.SqlError.ToString());
            }
            else
                MessageBox.Show("Запись успешно отредактирована!");
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            // хорошо бы запилить экранирование
            if (mydb.ExecuteNonQuery(cmdTextBox.Text) == 1)
            {
                MessageBox.Show(mydb.SqlError.ToString());
                
            }
            else 
                MessageBox.Show("Запрос выполнен!");
        }

        private void tableButton_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = mydb.FetchAll("birthday").DefaultView;
                DataRow[] dr = mydb.FetchAll("birthday").Select();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Таблица не создана!");
            }
        }
        #endregion
    }
}
